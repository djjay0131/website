# Milestone chain

Status as of 10 September 2026. Target: May 2027.

Each step gates the next. The order is not advisory.

---

## The binding constraint

**The preliminary exam must precede the final exam by at least six months.**

Everything upstream — committee approval, plan of study, proposal writing —
exists to get the prelim scheduled. Work the arithmetic backwards:

```
target defense date  −  6 months  =  prelim deadline
```

If that deadline has passed or is inside a few weeks, the target term is not
realistic. Better to know that in September than in February.

The six-month rule is verified policy. Graduation and ETD deposit deadlines are
**not** verified here — confirm them with the Graduate School for the term you
are targeting.

---

## 1. Coursework and M.S. — ✅ complete

M.S. Engineering conferred 05/2026. Nothing further except confirming that the
credits you intend to count appear correctly on the Plan of Study.

## 2. Internal committee formed — ✅ complete

Chair: Chris Brown. CS@VT requires at least three members holding tenured,
tenure-track, collegiate, professor-of-practice or emeritus appointments in the
department. Settled.

## 3. External member secured — 🔴 in progress, on the critical path

Target: identified and approached within two weeks.

Twelve vetted candidates ranked in [`committee-search.md`](committee-search.md),
weighted toward an industry or practice perspective. Recommended first approach:
Emerson Murphy-Hill, Microsoft Research.

**Gate:** this blocks the Plan of Study, which blocks the prelim. A cold email
that takes three weeks to answer is three weeks off the front of everything
downstream. Send more than one, staggered, rather than waiting on a single reply.

## 4. Graduate Committee Service Approval — 🔴 blocked by step 3

Submitted by the graduate coordinator, not by you. Send the candidate's CV or
NIH/NSF-style biosketch; the chain is coordinator → department head or GPD →
Graduate School.

**Unknown:** policy states no turnaround time, only that it precedes the Plan of
Study. Ask the coordinator what it actually takes right now. This is the step
most likely to quietly absorb a month.

## 5. Plan of Study filed — ⏳ next

CS@VT will process an initial Plan of Study with only **four** members
identified, so this does not have to wait for a signed-up external member. The
committee must be at five by the time the prelim is scheduled.

**Lever:** filing early with four is the one place in this chain where time can
be bought back. Take it.

## 6. Proposal written and circulated — ⏳ next

Three threads are already published or publishable:

- ICSE 2026 position paper on knowledge accumulation in SE
- the agentic knowledge-graph provenance substrate
- evidence-based-SE evaluation of generative coding tools

The proposal's job is to argue these are one dissertation rather than three
projects.

**Open question:** whether the mechanistic-interpretability work (binding
experiments, J-Lens) is a fourth chapter or gets cut. Decide before the
proposal, not during the prelim. Note that no candidate on the committee
shortlist covers this thread.

## 7. Preliminary exam — 🎯 the gate

Request in ESS at least two weeks ahead. Full committee must attend; remote
participation is normal, and there is no cap on remote participants.

**Hard rule:** the final exam cannot happen until six months after this date.

## 8. Research and writing — the six months

The mandatory gap is not dead time. Scheduled early enough, the gap and the
writing window overlap and the rule costs nothing. Scheduled late, it pushes
graduation a full semester.

## 9. Final defense and ETD — target

Request in ESS at least two weeks ahead. Leave room between the defense and the
ETD deposit deadline for committee-requested revisions.

---

## Status log

| Date | Step | Event |
|---|---|---|
| 2026-08-31 | 3 | External member search completed — 12 candidates ranked |
| 2026-09-10 | — | Milestone repository created |
