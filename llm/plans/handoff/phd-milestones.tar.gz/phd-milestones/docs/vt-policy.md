# VT doctoral committee and exam policy

Verified 31 August 2026 against CS@VT and Graduate School sources. Quoted
language is from the cited page or, where the live catalog blocks automated
access, from the most recent retrievable catalog text cross-checked against
currently posted forms.

---

## Committee composition

**Graduate School floor — four members.**

> "Doctoral candidates must have an Advisory Committee of at least four members
> with the qualifications described above."

**CS@VT requires five, with structure:**

> "At least five members. Ph.D. advisory committee must have five members by the
> time that the preliminary exam is scheduled."
>
> "At least three members must hold tenured/tenure-track, collegiate faculty,
> professor of practice or emeritus positions in the Department of Computer
> Science."
>
> "At least one member from outside the CS@VT Department. The external member
> must be approved prior to adding them to the committee."
>
> "All members must be pre-approved by the Graduate School."

— <https://students.cs.vt.edu/Graduate/Degrees/Doctorate.html>

**An initial Plan of Study is accepted with four members.**

> "A PhD advisory committee must have five members by the time that the
> preliminary exam is scheduled. However, we will process an initial Plan of
> Study with only four members of the committee identified."

— <https://students.cs.vt.edu/Graduate/Administrivia.html>

### The external requirement is narrower than it sounds

The CS rule says **outside the CS department**, not outside Virginia Tech. An
ECE, Statistics, or other VT department faculty member satisfies it. Nothing in
VT or CS policy requires an external-to-university examiner.

Going outside VT is therefore a choice made for the intellectual value, which
means the choice can be made purely on fit.

---

## Non-VT members

Policy sorts committee members into two tiers:

> "Advisory Committees will be composed principally of Virginia Tech-employed
> Graduate Program faculty members... Other individuals can be appointed to
> serve as Members or as Co-Chairs... This category includes retired or Emeritus
> Virginia Tech faculty members, Virginia Tech employees (e.g., Research
> Scientists), and non-Virginia Tech-employed individuals including Adjunct
> Faculty."
>
> "Graduate Program faculty members must constitute at least two-thirds of the
> minimum committee membership."

The service-approval instrument states the same limits and the credential test:

> non-VT members "may not chair advisory committees" and "may not make up more
> than 1/3 of the committee"
>
> qualified by "terminal degree/professional experience, scholarly activity, and
> potential to enrich students' program"
>
> "Attach a NIH- or NSF-style bio sketch or short CV (showing degree credentials
> and active scholarship status...)"

— <https://sas.vt.edu/content/dam/apsc_vt_edu/graduate-program/graduate-committee-service-approval-form.pdf>

**No separate faculty appointment is required.** Approval is a per-person (or
one-time, per-student) committee-service approval by the Graduate School.

### Industry PhDs

Policy does not restrict by employer type. The "Other individuals" tier
explicitly covers "non-Virginia Tech-employed individuals," and the
qualification test names **professional experience** as an alternative to a
purely academic record.

Constraints that do apply: cannot chair; counts against the ≤1/3 cap. On a
five-member CS committee with three CS Graduate Program faculty, one external
seat is comfortably within the cap.

### Voting

Policy defines only Chair, Co-Chair, and Member — there is **no non-voting or
observer category**. An approved Member is a member of record in the exam
system, and exam results require each member to record approval or disapproval.
Policy does not use the phrase "voting member," so treat this as the structural
implication rather than a quoted rule.

---

## Approval process

1. **Committee-service approval for the non-VT member — do this first.**

   > "To propose a non-Virginia Tech professor/researcher to serve on your
   > advisory committee, please send the most recent CV/professional website to
   > your graduate coordinator who will then submit the credentials for approval
   > to the Graduate School. This should be completed prior to the submission of
   > the plan of study worksheet."

   — <https://students.cs.vt.edu/Graduate/Forms.html>

   Chain: graduate coordinator → department head or GPD → Graduate School.
   Required fields include advanced degrees with institution and year, products
   of scholarly effort within the last year (limit 10), and experience with
   graduate education within the last five years.

   — <https://graduateschool.vt.edu/content/dam/graduateschool_vt_edu/forms/Guide_to_committee_service_online_form.pdf>

2. **Plan of Study** — or, if the committee already exists, a Change of
   Committee/Advisor Request, which requires signatures from all committee
   members.

3. **Exam request in ESS** — <https://ess.graduateschool.vt.edu> — at least two
   weeks before the intended exam date.

---

## Exams

**Six-month rule.** The preliminary exam must precede the final exam by at least
six months. This is the binding constraint on any graduation timeline.

**Remote participation is permitted and normal.**

> "Preliminary or final oral exams may be carried out remotely, and Zoom is a
> capable tool for such exams."
>
> "a graduate exam held over Zoom must be scheduled through ESS in the usual way
> so that committee members can verify their participation"
>
> "the requirement in a graduate exam is that the entire committee is present and
> engaged with the exam so as to render an immediate result"

— <https://graduateschool.vt.edu/academics/what-you-need-to-graduate/basics-zoom-graduate-exams.html>

The operative requirement is whole-committee presence and engagement in real
time, not physical presence. Policy does not cap the number of remote
participants and does not require an in-person quorum.

---

## Explicitly not stated in policy — do not assume

- **No required lead time** for Graduate School approval of a non-VT member.
  Only its sequencing (before the Plan of Study) is specified.
- **No rule** requiring the external member to be from another university, or
  barring industry employment.
- **No explicit "voting member" language**, and no non-voting category.
- **No cap** on how many committee members may be remote.

---

## Authority of record

The CS graduate program director / graduate coordinator decides whether a
specific proposed member qualifies, and knows current turnaround. Blacksburg
MS/PhD coordinator is listed as Ms. Sharon Kinder-Potter.

Graduate School: grads@vt.edu · 540-231-6691

## Sources

- <https://students.cs.vt.edu/Graduate/Degrees/Doctorate.html>
- <https://students.cs.vt.edu/Graduate/Administrivia.html>
- <https://students.cs.vt.edu/Graduate/Forms.html>
- <https://graduateschool.vt.edu/faculty-and-staff-resources.html>
- <https://graduateschool.vt.edu/content/dam/graduateschool_vt_edu/forms/Guide_to_committee_service_online_form.pdf>
- <https://sas.vt.edu/content/dam/apsc_vt_edu/graduate-program/graduate-committee-service-approval-form.pdf>
- <https://graduateschool.vt.edu/academics/what-you-need-to-graduate/basics-zoom-graduate-exams.html>
- <https://graduateschool.vt.edu/content/dam/graduateschool_vt_edu/process/narrative-for-exam-scheduling-flowchart.pdf>
- <https://catalog.vt.edu/graduate/graduate-policies> (live policy; not machine-fetchable)
