# External committee member search

Compiled 31 August 2026. Affiliations verified that date against first-party or
conference-official pages.

Rendered version: `site/committee.html`

> **Handling:** this document contains candid assessments of named researchers.
> Working material, not publishable commentary. Keep the project private.

---

## Criteria

Matched against four threads drawn from the CV and current writing:

| | Thread |
|---|---|
| **A** | Agent-orchestrated knowledge graphs as a provenance substrate for grounded research QA, measured by downstream faithfulness |
| **B** | Verifying rather than asserting claims from LLM-assisted work; evidence-based SE |
| **C** | Knowledge accumulation in SE and a provenance-tracked artifact model (ICSE 2026, 280-researcher survey) |
| **D** | VVUQ layer for reproducibility of engineering-simulation claims |

Stated preferences: industry or practice perspective plus topical expertise;
non-academic PhD acceptable; remote participation fine.

---

## Ranked shortlist

### Tier 1 — approach first

| # | Name | Affiliation (verified 2026-08-31) | Threads | Note |
|---|---|---|---|---|
| 1 | **Emerson Murphy-Hill** | Principal Researcher, **Microsoft Research** (PROSE/CHISE) | B, C | MSR 2026 keynote is literally the dissertation question. Industry + former tenured faculty = has committee experience. **Not Google — that is stale.** |
| 2 | **Doug Downey** | Senior Director, Semantic Scholar Research, **Ai2** *and* Professor, **Northwestern** | A, C | Dual appointment resolves the industry-vs-committee-experience tension. Ai2 Scholar QA = attributed literature synthesis. |
| 3 | **Juan Sequeda** | Principal Fundamental Researcher, **ServiceNow** (data.world acquired May 2025) | A | Canonical KG-improves-LLM-QA benchmark. No committee track record; enterprise data, not SE. |
| 4 | **Ciera Jaspan** | TLM, Engineering Productivity Research, **Google** | B | Measurement rigor at scale. No academic-committee record. |

### Tier 2 — strong, with a named caveat

| # | Name | Affiliation | Threads | Caveat |
|---|---|---|---|---|
| 5 | **Emad Shihab** | Professor, **Concordia**; Director, DAS Lab | A, B | Closest published prior work to thread A. But Associate Dean, Research & Innovation. |
| 6 | **Sebastian Baltes** | Professor (W3), **Heidelberg** since Oct 2025 | B, C | First author, LLM empirical study guidelines. Just moved — bandwidth. Use *Heidelberg* on VT paperwork, not Bayreuth/Adelaide. |
| 7 | **Christian Bird** | Principal Researcher, **Microsoft Research** DevEx Lab | B | Overlaps Murphy-Hill substantially — approach one, not both. |
| 8 | **Juliana Freire** | Institute Professor, **NYU Tandon**; VIDA Center | A, D | Will test thread A against PROV/VisTrails prior art. Outside SE community. |
| 9 | **Aakanksha Naik** | Researcher, **Ai2** | A | Faithfulness meta-evaluation. Take her *or* Downey, not both. |
| 10 | **Paul Ralph** | Professor, **Dalhousie**; EiC, SIGSOFT Empirical Standards | B, C | Highest authority on the standards the thesis invokes. No industry seat. |
| 11 | **Sarah Fakhoury** | Senior Researcher, **Microsoft Research** RiSE | B, D | Empirical evaluation *and* formal verification — rare touch on thread D. More junior. |
| 12 | **Rahul Krishna** | Research Staff Member, **IBM Research** | B | Menzies lineage; "Are We There Yet?" is the thesis move executed early. Stale profile — verify he is still there. |

---

## Recommendation

No single person covers all four threads and there is one seat. The choice is
which half of the dissertation gets external scrutiny.

1. **Ask Murphy-Hill first.** Only candidate publicly asking this question, from
   industry, who has supervised doctoral students. His Microsoft move also puts
   him one hallway from Bird, Fakhoury and the DevEx lab.
2. **If the KG is the risk,** Downey over Sequeda — same subject matter, but the
   professorship means VT's paperwork goes through without friction.
3. **If Murphy-Hill declines,** Jaspan for the measurement seat, or Baltes to
   trade the industry seat for survey-methodology defense.

**Gap:** the mechanistic-interpretability thread (binding, J-Lens) has zero
coverage from this list. If it becomes a chapter, it needs its own search.

---

## Ruled out

| Name | Reason |
|---|---|
| Miltos Allamanis | At Apple since June 2026; states on his own site he has "ceased to work/submit academic publications" |
| Satish Chandra | At **Meta**, not Google; leads a large org, no realistic bandwidth |
| Denae Ford Robinson | 2025–26 output moved into AI-mediated communication and agent HCI |
| Austin Henley | Microsoft Excel Agent science team; CMU role was a teaching professorship |
| Nicole Forsgren | Output now trade books and keynotes; stated role and MSR lab page disagree |
| Titus Barik | Apple — most restrictive publication/disclosure culture on the list |
| Denys Poshyvanyk | Excellent fit but same state system, ~3.5h away; confirm VT's "external" definition first |
| Christoph Treude | SMU Singapore, UTC+8; TSE Associate EiC *and* FSE 2026 PC Co-Chair |
| Jennifer D'Souza / Sören Auer | ORKG at TIB Hannover — **cite this prior art in thread C**, but she is a group lead and he directs a national library |

---

## Confidence and gaps

- **Strongest data:** current affiliations. Each verified against a first-party
  or conference-official page on 2026-08-31. Six names in circulation had stale
  affiliations — re-check before anything goes into VT paperwork.
- **Weakest data:** PhD institutions, exact contact routes, and willingness to
  serve. No public signal exists for the last of these. Every risk note is
  inferred from observable service load, not from any statement of availability.
- **Not assessed:** overlap or conflicts with the existing internal committee.

---

## Status log

| Date | Candidate | Event |
|---|---|---|
| 2026-08-31 | — | Search completed, 12 candidates ranked |
