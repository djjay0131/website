# phd-milestones

Working repository for finishing the Virginia Tech CS PhD: the milestone chain,
the policy constraints that govern it, and the research behind each decision.

Deployed as a private GitLab Pages site so the current state is one URL away
instead of buried in a chat log or a Drive folder.

| | |
|---|---|
| **Candidate** | Jason Cusati (djjay@vt.edu) |
| **Advisor** | Chris Brown |
| **Program** | Computer Science — Software Engineering with AI/ML/MI |
| **Target** | May 2027 |

---

## ⚠️ Keep this project private

This repository contains candid assessments of named researchers — judgments
about their availability, their current research direction, and why some were
ruled out. It is working material for committee selection, **not publishable
commentary**, and publishing it under your own name would be unfair to them and
bad for you.

Two settings, both required:

1. **Settings → General → Visibility** → Project visibility: **Private**
2. **Deploy → Pages** → Access Control: **Only project members**

Direct email addresses are deliberately kept out of the published HTML. They
live in the private project notes instead.

---

## Layout

```
site/                 # what gets published
  index.html          # milestone chain + prelim/defense date calculator
  committee.html      # external committee member dossier
  assets/style.css    # shared stylesheet, light + dark
docs/                 # markdown source of record
  milestones.md       # the chain, in plain text
  vt-policy.md        # verified VT rules with citations
  committee-search.md # the search: method, criteria, findings
.gitlab-ci.yml        # Pages deploy
```

`site/` is plain static HTML with no build step and no dependencies. Open any
file directly in a browser to preview; the CI job just copies it into `public/`.

---

## Setup

The project does not exist on GitLab yet. Create it and push:

```bash
# 1. Create an empty project at https://code.vt.edu — name it "phd-milestones",
#    set visibility to Private, and do NOT initialize it with a README.

# 2. From this directory:
git remote add origin https://code.vt.edu/<your-username>/phd-milestones.git
git push -u origin main
```

The `pages` job runs on the default branch and publishes within a minute or two.
Find the URL under **Deploy → Pages**.

If VT's GitLab requires SSH, swap the remote for
`git@code.vt.edu:<your-username>/phd-milestones.git`.

---

## Working on it

Everything is hand-maintained markdown and HTML. When something changes:

- **A milestone moves** — edit `site/index.html` (the `.step` list) and
  `docs/milestones.md`. Status is carried by the `done` / `now` class on the
  `<li>` and the matching `.pill`.
- **A candidate replies** — record the outcome in `docs/committee-search.md`
  under Status log, and update the dossier if it changes the ranking.
- **A policy detail is confirmed** — move it from "unverified" to the verified
  list in `docs/vt-policy.md` with the source, and mirror it on the index page.

Keep the distinction between verified policy and working estimate visible in
the text. It is the thing that makes this document trustworthy six months from
now, when nobody remembers which was which.

---

## What is not verified here

- **Graduation and ETD deposit deadlines.** The six-month prelim-to-final rule
  is verified policy; the specific calendar dates are not. Confirm them with the
  Graduate School for the term you are targeting.
- **Anyone's willingness to serve.** Every risk note in the dossier is inferred
  from observable service load, not from any statement of availability.
- **Committee-service approval turnaround.** Policy states no lead time, only
  that it precedes the Plan of Study. Ask the graduate coordinator.
